module.exports = {
    authController: require('./auth'),
    favoriteController: require('./favorite')
}