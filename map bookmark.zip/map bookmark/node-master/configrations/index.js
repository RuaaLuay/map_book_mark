module.exports={
    dbConnection: require('./db')
}