module.exports={
    userModel: require('./User'),
    coordinateModel: require('./Coordinate'),
    placeModel: require('./Place'),
}