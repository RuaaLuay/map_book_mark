<template>
<div>
<!-- <router-link to="/">MAp</router-link>
  <router-link to="/login">About</router-link> -->

  <router-view></router-view>
</div>
  
  <!-- <loginScreem /> -->
</template>

<script>

export default {
  name: "App",
 
};
</script>
